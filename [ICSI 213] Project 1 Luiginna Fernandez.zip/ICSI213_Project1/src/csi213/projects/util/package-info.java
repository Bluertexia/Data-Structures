/**
 * Provides utility classes.
 */
package csi213.projects.util;