/**
 * Provides classes representing computers.
 */
package csi213.projects.computers;